# 📦 Deployment Package - SEO Local

## ✅ Contenido del Paquete

Este paquete contiene TODOS los archivos necesarios para el deployment del sistema de SEO local.

### Estructura de Archivos

```
DEPLOYMENT_SEO_PACKAGE/
│
├── sitemap.xml                    # Sitemap actualizado con 13 ciudades
│
├── includes/
│   ├── ciudades-data.php         # Data de 13 ciudades
│   └── faq-schema.php            # Helper para FAQs
│
└── seguridad-{ciudad}/           # 13 carpetas de ciudades
    └── index.php                 # Página dinámica optimizada
```

## 🚀 Instrucciones de Deployment

### Paso 1: Acceder al Servidor

**Opción A - FTP/SFTP:**
- Usar FileZilla o similar
- Conectar al servidor
- Navegar a la carpeta raíz del sitio

**Opción B - Plesk File Manager:**
- Login en panel Plesk
- File Manager → httpdocs/ (o public_html/)

### Paso 2: Subir Archivos

1. **Subir sitemap.xml** → Raíz del sitio
   - Sobrescribirá el sitemap existente
   
2. **Subir carpeta includes/** → Raíz del sitio
   - Añadirá 2 archivos nuevos (no sobrescribe nada)
   
3. **Subir 13 carpetas seguridad-*/** → Raíz del sitio
   - Son carpetas completamente nuevas

### Paso 3: Verificar Permisos

Asegurar permisos correctos:
- Carpetas: 755
- Archivos PHP: 644

### Paso 4: Verificación

Probar estas URLs:
- https://praxisseguridad.es/sitemap.xml
- https://praxisseguridad.es/seguridad-santomera/
- https://praxisseguridad.es/seguridad-en-murcia/

Si todas cargan correctamente → ✅ Deployment exitoso

## 📋 Post-Deployment

1. **Google Search Console:**
   - Añadir sitemap: https://praxisseguridad.es/sitemap.xml
   
2. **Solicitar indexación** de páginas principales:
   - seguridad-santomera
   - seguridad-en-murcia
   - seguridad-alicante

3. **Validar schemas:**
   - https://search.google.com/test/rich-results
   - Probar con URL de Santomera

## ⚠️ Troubleshooting

**Error: "Failed to open stream"**
→ Verificar que /includes/ciudades-data.php existe

**Página en blanco**
→ Revisar error logs de PHP en el servidor

**404 Not Found**
→ Verificar que las carpetas se crearon correctamente

## 🎯 Resultado Esperado

Tras deployment exitoso:
- ✅ 13 nuevas páginas accesibles
- ✅ Sitemap con 26 URLs totales (13 principales + 13 locales)
- ✅ Sin errores PHP
- ✅ Schemas validados
- ✅ Listo para SEO

---

**Tiempo estimado de deployment:** 10-15 minutos
**Riesgo:** Bajo (archivos nuevos, no modifica código existente)
**Beneficio:** Alto (13 páginas optimizadas para SEO local)
