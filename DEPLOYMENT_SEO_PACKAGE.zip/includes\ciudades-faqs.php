<?php
/**
 * FAQs por ciudad para SEO local
 * Sistema expandido con más preguntas por ciudad
 */

return [
    'santomera' => [
        [
            'pregunta' => '¿Praxis Seguridad tiene oficina en Santomera?',
            'respuesta' => 'Sí, nuestra base de operaciones está ubicada en Santomera, Murcia. Esto nos permite ofrecer tiempo de respuesta inferior a 15 minutos en toda la zona de Santomera y municipios cercanos.'
        ],
        [
            'pregunta' => '¿Qué servicios de seguridad ofrecen en Santomera?',
            'respuesta' => 'Ofrecemos vigilancia 24/7, control de accesos, seguridad para naves industriales, sistemas de alarmas CCTV, protección de eventos y seguridad específica para empresas logísticas y almacenes en Santomera.'
        ],
        [
            'pregunta' => '¿Cuánto tiempo tardan en responder a una emergencia?',
            'respuesta' => 'Gracias a nuestra base operativa en Santomera, garantizamos un tiempo de respuesta inferior a 15 minutos en toda la zona local, disponible 24 horas al día, 7 días a la semana.'
        ],
        [
            'pregunta' => '¿Están autorizados por el Ministerio del Interior?',
            'respuesta' => 'Sí, Praxis Seguridad está plenamente autorizada y cumple con toda la normativa vigente de seguridad privada del Ministerio del Interior. Todo nuestro personal está debidamente acreditado.'
        ]
    ],
    'murcia' => [
        [
            'pregunta' => '¿Praxis Seguridad opera en Murcia capital?',
            'respuesta' => 'Sí, prestamos servicios de seguridad privada en Murcia capital con cobertura completa. Nuestro tiempo de respuesta desde Santomera es de aproximadamente 25 minutos.'
        ],
        [
            'pregunta' => '¿Qué empresas contratan sus servicios en Murcia?',
            'respuesta' => 'Trabajamos con administraciones públicas, centros comerciales, empresas de servicios, centros educativos, hospitales y cualquier negocio que necesite seguridad profesional en Murcia.'
        ],
        [
            'pregunta' => '¿Ofrecen vigilancia para edificios de oficinas?',
            'respuesta' => 'Sí, ofrecemos servicios especializados de vigilancia y control de accesos para edificios empresariales, centros de negocios y complejos de oficinas en Murcia.'
        ],
        [
            'pregunta' => '¿Puedo contratar seguridad solo por las noches?',
            'respuesta' => 'Sí, ofrecemos servicios flexibles adaptados a sus necesidades, incluyendo vigilancia nocturna, fines de semana o eventos puntuales en Murcia.'
        ]
    ],
    'alicante' => [
        [
            'pregunta' => '¿Dan servicio de seguridad en Alicante?',
            'respuesta' => 'Sí, prestamos servicios de seguridad privada en Alicante capital y provincia, especializados en comercios, hoteles, residenciales y empresas de servicios.'
        ],
        [
            'pregunta' => '¿Cuál es el tiempo de respuesta en Alicante?',
            'respuesta' => 'El tiempo de respuesta desde nuestra base en Santomera hasta Alicante es de aproximadamente 45 minutos para situaciones de emergencia.'
        ],
        [
            'pregunta' => '¿Ofrecen seguridad para hoteles?',
            'respuesta' => 'Sí, tenemos amplia experiencia en seguridad hotelera, incluyendo vigilancia de instalaciones, control de accesos y seguridad para eventos en hoteles de Alicante.'
        ],
        [
            'pregunta' => '¿Trabajan con centros comerciales?',
            'respuesta' => 'Sí, ofrecemos servicios especializados para centros comerciales incluyendo vigilancia, prevención de pérdidas y control de accesos en Alicante.'
        ]
    ],
    'valencia' => [
        [
            'pregunta' => '¿Ofrecen servicios de seguridad en Valencia?',
            'respuesta' => 'Sí, damos cobertura completa en Valencia capital para empresas de tecnología, logística portuaria, servicios, turismo y sector industrial.'
        ],
        [
            'pregunta' => '¿Cuánto tardan en llegar desde Santomera?',
            'respuesta' => 'El tiempo estimado de respuesta desde nuestra base en Santomera hasta Valencia es de aproximadamente 90 minutos para emergencias.'
        ],
        [
            'pregunta' => '¿Tienen experiencia con empresas tecnológicas?',
            'respuesta' => 'Sí, trabajamos con empresas del sector tecnológico proporcionando seguridad física y control de accesos para oficinas, centros de datos y eventos en Valencia.'
        ],
        [
            'pregunta' => '¿Ofrecen seguridad para el Puerto de Valencia?',
            'respuesta' => 'Sí, prestamos servicios de vigilancia y control para empresas logísticas y operadores en la zona portuaria de Valencia.'
        ]
    ],
    'elche' => [
        [
            'pregunta' => '¿Prestan servicios en Elche?',
            'respuesta' => 'Sí, ofrecemos servicios completos de seguridad privada en Elche, especialmente para el sector industrial del calzado y empresas manufactureras.'
        ],
        [
            'pregunta' => '¿Qué tiempo de respuesta tienen en Elche?',
            'respuesta' => 'El tiempo de respuesta desde Santomera hasta Elche es de aproximadamente 35 minutos.'
        ],
        [
            'pregunta' => '¿Trabajan con fábricas de calzado?',
            'respuesta' => 'Sí, tenemos experiencia específica en seguridad para fábricas y almacenes del sector calzado en Elche, incluyendo vigilancia y control de accesos.'
        ]
    ],
    'torrevieja' => [
        [
            'pregunta' => '¿Dan servicio en Torrevieja?',
            'respuesta' => 'Sí, prestamos servicios de seguridad en Torrevieja, especializados en residenciales turísticos, comunidades y comercios.'
        ],
        [
            'pregunta' => '¿Ofrecen seguridad para urbanizaciones?',
            'respuesta' => 'Sí, tenemos amplia experiencia en seguridad para urbanizaciones residenciales y complejos turísticos en Torrevieja.'
        ]
    ],
    'almeria' => [
        [
            'pregunta' => '¿Operan en Almería?',
            'respuesta' => 'Sí, ofrecemos servicios de seguridad en Almería, especialmente para empresas agrícolas, invernaderos tecnificados y sector logístico.'
        ],
        [
            'pregunta' => '¿Tienen experiencia con empresas agrícolas?',
            'respuesta' => 'Sí, trabajamos con empresas del sector agrícola proporcionando vigilancia de instalaciones, control de accesos y seguridad de almacenes en Almería.'
        ]
    ],
    'fortuna' => [
        [
            'pregunta' => '¿Prestan servicios en Fortuna?',
            'respuesta' => 'Sí, ofrecemos seguridad privada en Fortuna con tiempo de respuesta de 15 minutos, especializado en balnearios, turismo termal y comercios locales.'
        ]
    ],
    'abanilla' => [
        [
            'pregunta' => '¿Dan servicio en Abanilla?',
            'respuesta' => 'Sí, prestamos servicios de seguridad en Abanilla con respuesta rápida inferior a 15 minutos, enfocados en el sector agrícola y empresas locales.'
        ]
    ],
    'molina-segura' => [
        [
            'pregunta' => '¿Operan en Molina de Segura?',
            'respuesta' => 'Sí, ofrecemos servicios completos en Molina de Segura, especialmente para polígonos industriales y empresas manufactureras.'
        ],
        [
            'pregunta' => '¿Trabajan en polígonos industriales?',
            'respuesta' => 'Sí, tenemos amplia experiencia en seguridad para polígonos industriales de Molina de Segura, incluyendo vigilancia 24/7 y control de accesos.'
        ]
    ],
    'alcantarilla' => [
        [
            'pregunta' => '¿Prestan servicios en Alcantarilla?',
            'respuesta' => 'Sí, ofrecemos seguridad en Alcantarilla enfocados en empresas logísticas, almacenes y sector industrial con tiempo de respuesta de 20 minutos.'
        ]
    ],
    'torres-cotillas' => [
        [
            'pregunta' => '¿Dan servicio en Las Torres de Cotillas?',
            'respuesta' => 'Sí, prestamos servicios de seguridad en Las Torres de Cotillas, especializados en empresas manufactureras y polígonos industriales.'
        ]
    ],
    'orihuela' => [
        [
            'pregunta' => '¿Operan en Orihuela?',
            'respuesta' => 'Sí, ofrecemos servicios en Orihuela y Orihuela Costa, incluyendo seguridad para residenciales, comercios y sector turístico.'
        ],
        [
            'pregunta' => '¿Cubren Orihuela Costa?',
            'respuesta' => 'Sí, damos cobertura tanto a Orihuela ciudad como a Orihuela Costa, con servicios adaptados al sector residencial y turístico.'
        ]
    ]
];
