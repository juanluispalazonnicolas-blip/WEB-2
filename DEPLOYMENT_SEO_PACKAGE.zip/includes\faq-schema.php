<?php
/**
 * Schema FAQPage para SEO
 * Añadir este código a las páginas locales para responder preguntas frecuentes
 */

$faqs_por_ciudad = [
    'santomera' => [
        [
            'pregunta' => '¿Praxis Seguridad tiene oficina en Santomera?',
            'respuesta' => 'Sí, nuestra base de operaciones está ubicada en Santomera, lo que nos permite ofrecer tiempo de respuesta inferior a 15 minutos en toda la zona.'
        ],
        [
            'pregunta' => '¿Qué servicios de seguridad ofrecen en Santomera?',
            'respuesta' => 'Ofrecemos vigilancia 24/7, control de accesos, seguridad para naves industriales, sistemas de alarmas y protección específica para empresas logísticas en Santomera.'
        ],
        [
            'pregunta' => '¿Cuánto tiempo tardan en responder a una emergencia en Santomera?',
            'respuesta' => 'Gracias a nuestra base en Santomera, garantizamos un tiempo de respuesta inferior a 15 minutos en toda la zona.'
        ]
    ],
    'murcia' => [
        [
            'pregunta' => '¿Praxis Seguridad opera en Murcia capital?',
            'respuesta' => 'Sí, ofrecemos servicios de seguridad privada en Murcia capital con tiempo de respuesta de aproximadamente 25 minutos desde nuestra base en Santomera.'
        ],
        [
            'pregunta' => '¿Qué tipo de empresas pueden contratar sus servicios en Murcia?',
            'respuesta' => 'Trabajamos con administraciones públicas, comercios, empresas de servicios, centros educativos y cualquier negocio que necesite seguridad profesional en Murcia.'
        ]
    ],
    'alicante' => [
        [
            'pregunta' => '¿Dan servicio de seguridad en Alicante?',
            'respuesta' => 'Sí, prestamos servicios de seguridad privada en Alicante capital, especializados en comercios, hoteles y empresas de servicios.'
        ],
        [
            'pregunta' => '¿Cuál es el tiempo de respuesta en Alicante?',
            'respuesta' => 'El tiempo de respuesta desde nuestra base en Santomera hasta Alicante es de aproximadamente 45 minutos.'
        ]
    ],
    'valencia' => [
        [
            'pregunta' => '¿Ofrecen servicios de seguridad en Valencia?',
            'respuesta' => 'Sí, damos cobertura en Valencia capital para empresas de tecnología, logística portuaria, servicios y turismo.'
        ],
        [
            'pregunta' => '¿Qué tardan en llegar a Valencia ante una emergencia?',
            'respuesta' => 'El tiempo estimado de respuesta desde Santomera hasta Valencia es de aproximadamente 90 minutos.'
        ]
    ]
];

// Función para generar el schema FAQPage
function generar_faq_schema($ciudad_key, $faqs_por_ciudad) {
    if (!isset($faqs_por_ciudad[$ciudad_key])) {
        return '';
    }
    
    $faqs = $faqs_por_ciudad[$ciudad_key];
    $faq_items = [];
    
    foreach ($faqs as $faq) {
        $faq_items[] = [
            '@type' => 'Question',
            'name' => $faq['pregunta'],
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => $faq['respuesta']
            ]
        ];
    }
    
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => $faq_items
    ];
    
    return json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}
?>
